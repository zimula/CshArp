﻿namespace Exercise_CardDeck
{
    enum Color
    {
        Spade, //0
        Club, //1
        Heart, //2
        Diamonds, //3
    }
    enum Rank
    {
        Ace,
        Two,
        Three,
        Four,
        Five,
        Six,
        Seven,
        Eight,
        Nine,
        Teen,
        Jack,
        Queen,
        King
    }
}
