﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ducks
{
    public class Duck
    {
        public string Name { get; set; }
        public void Quack()
        {
            Console.WriteLine("Kvæk kvæk");
        }
        public void Swim()
        {
            Console.WriteLine("Svømmer");
        }
    }

    public class Mallard : Duck
    {
        public Mallard(string id)
        {
            Name = id;
        }
    }

    public class ReadHeadDuck : Duck
    {
        public ReadHeadDuck(string id)
        {
            Name = id;
        }
    }
}
