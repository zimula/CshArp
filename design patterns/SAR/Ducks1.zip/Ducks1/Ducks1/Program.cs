﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ducks
{
    class Program
    {
        static void Main(string[] args)
        {
            Mallard graaand = new Mallard("Gråand");
            Helper(graaand);

            ReadHeadDuck readHead = new ReadHeadDuck("Rødand");
            Helper(readHead);

            Console.ReadLine();
        }

        static void Helper(Duck myDuck)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(myDuck.Name);
            Console.ResetColor();
            myDuck.Quack();
            myDuck.Swim();
            Console.WriteLine("-------------");
        }
    }
}
