﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ducks
{
    public abstract class Duck
    {
        public IFlyStrategy flyStrategy { get; protected set; }
        public IQuackStrategy quackStrategy;
        public ISwimStrategy swimStrategy;
        

        public string Name { get; protected set; }
    }
}
